package com.test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class DataFromProperties {

    private static final ObjectMapper mapper = new ObjectMapper();
    private static JsonNode root;

    private static File media = new File("media.properties.JSON");

    public static JsonNode retrieveDataAsJsonNode() {
        try {
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
            root = mapper.readTree(media);

        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return root;
    }

    public static void writeData(DigitalVideoDisc object) {
        try {
            mapper.writeValue(media, object);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static ArrayList<DigitalVideoDisc> retrieveDataAsArrayList() throws IOException {
        ArrayList<DigitalVideoDisc> list = new ArrayList<>();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        root = mapper.readTree(media);
        for (JsonNode obj : root) {
            list.add(new DigitalVideoDisc(obj.get("title").asText(), obj.get("category").asText(), Integer.parseInt(obj.get("priceInDollars").asText()), obj.get("director").asText()));
        }
        return list;
    }

    public static void deleteProperty(String title)throws IOException {
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        root = mapper.readTree(media);
        for (JsonNode node : root) {
            if (node.get("title").asText().equals(title))
                ((ObjectNode) node).removeAll();
        }
    }

    public static void addProperty(DigitalVideoDisc digitalVideoDisc)throws IOException{
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        mapper.writeValue(media,digitalVideoDisc);
    }



}
