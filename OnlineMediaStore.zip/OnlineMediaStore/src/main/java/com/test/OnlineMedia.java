package com.test;

import java.util.ArrayList;
import java.util.Scanner;

public class OnlineMedia {
    public static void printArrayList(ArrayList<DigitalVideoDisc> l) {
        int index = 0;
        for (DigitalVideoDisc disc : l) {
            System.out.println(index + "." + disc.getTitle());
            index++;
        }
    }

    public static void main(String[] args) {

        try {
            System.out.println("Hi you are entering as ?");
            System.out.println("1.Client");
            System.out.println("2.Manager");
            System.out.println("Answer: ");
            byte ans;
            Scanner input = new Scanner(System.in);
            ans = input.nextByte();

            switch (ans) {
                case 1:
                    ArrayList<DigitalVideoDisc> listOfDiscs = DataFromProperties.retrieveDataAsArrayList();
                    ArrayList<DigitalVideoDisc> listOfPicks = new ArrayList<>();
                    System.out.println("Enter name: ");
                    String name = input.next();
                    System.out.println("Enter surname: ");
                    String surname = input.next();
                    System.out.println("You want to order something :");
                    System.out.println("1.yes\n2.no");
                    ans = input.nextByte();
                    byte discAns;
                    while (ans == 1) {

                        if (listOfDiscs.isEmpty()) break;
                        //break if all discs were chosen

                        printArrayList(listOfDiscs);
                        System.out.println("Press the number of the movie you want to add !");
                        discAns = input.nextByte();
                        if (discAns < listOfDiscs.size() && discAns >= 0) {
                            listOfPicks.add(listOfDiscs.get(discAns));
                            listOfDiscs.remove(discAns);
                        }
                        System.out.println("Continue ?!");
                        System.out.println("1.yes\n2.no");
                        ans = input.nextByte();
                    }
                    Order order = new Order(name, surname);
                    order.setDigitalVideoDiscs(listOfPicks);
                    System.out.println(order.getName() + " " + order.getSurname() + " has ordered: ");
                    printArrayList(order.getDigitalVideoDiscs());
                    break;

                case 2:
                    System.out.println("1.You want to add a new DVD\n2.You want to delete a DVD");
                    byte decision = input.nextByte();
                    if (decision == 1) {
                        while (decision == 1) {
                            System.out.println("Enter title \n(for whitespaces use underscore(_) ): ");
                            String title = input.next();
                            System.out.println("Enter category \n(for whitespaces use underscore(_) ): ");
                            String category = input.next();
                            System.out.println("Enter price in dollars: ");
                            int priceInDollars = input.nextInt();
                            System.out.println("Enter director\n(for whitespaces use underscore(_) ): ");
                            String director = input.next();
                            DigitalVideoDisc digitalVideoDisc = new DigitalVideoDisc(title, category, priceInDollars, director);
                            DataFromProperties.addProperty(digitalVideoDisc);
                            System.out.println("Continue adding ?\n1.Yes\n2.No");
                            decision = input.nextByte();
                        }
                    } else {
                        decision = 1;
                        while (decision == 1) {
                            printArrayList(DataFromProperties.retrieveDataAsArrayList());
                            System.out.println("Enter title of DVD you want to remove: ");
                            String title = input.nextLine();
                            DataFromProperties.deleteProperty(title);
                            System.out.println("Continue removing ?\n1.Yes\n2.No");
                            decision = input.nextByte();
                        }
                    }
                    break;
                default:
                    System.out.println("You entered some invalid value !");
                    break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
